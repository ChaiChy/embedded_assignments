
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'V1-4' 
 * Target:  'Target 1' 
 */

#ifndef PRE_INCLUDE_GLOBAL_H
#define PRE_INCLUDE_GLOBAL_H

/* Keil::Device:STM32Cube LL:Common:1.8.1 */
#define USE_FULL_LL_DRIVER


#endif /* PRE_INCLUDE_GLOBAL_H */
