void DACInit(void);			// Initialisierung des DAC-Konverters
void DACWrite(int analog); // Ausgabe  des Analogwertes 0..4095
