void ADCInit(int ADCChannel);
int ADCRead(void);
