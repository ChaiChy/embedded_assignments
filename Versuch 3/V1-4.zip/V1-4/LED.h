void LEDInit(void);
void LEDSet(int nr);
void LEDReset(int nr);
